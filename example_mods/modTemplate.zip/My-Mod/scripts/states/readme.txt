Add state-specific scripts here!

Create a folder for each state (e.g., "MainMenuState", "TitleState", "StoryMenuState").
Scripts inside each state folder will run only when that state is active.

Supported formats: .lua (with bugs), .hx
